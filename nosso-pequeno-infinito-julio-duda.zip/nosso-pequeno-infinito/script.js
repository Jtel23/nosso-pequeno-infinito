// ===================== PERSONALIZE AQUI =====================
// Coloque a data em que vocês começaram a namorar no formato AAAA-MM-DD.
// Exemplo: const relationshipStart = "2026-01-15";
const relationshipStart = "2026-08-04"; // O dia em que Julio e Duda se conheceram

// Se tiverem um arquivo de áudio que possam usar, coloque-o em assets/nossa-musica.mp3
// e troque a linha abaixo para: const songFile = "assets/nossa-musica.mp3";
// Alternativa: edite index.html para incorporar um vídeo de YouTube.
const songFile = ""; // Música favorita: "Until I Found You" — use o player oficial/incorporação autorizada
// ============================================================

const counter = document.getElementById("counter");
function updateCounter() {
  if (!relationshipStart) {
    counter.textContent = "Um montão de momentos por vir. ♡";
    return;
  }
  const start = new Date(`${relationshipStart}T00:00:00`);
  if (Number.isNaN(start.getTime()) || start > new Date()) {
    counter.textContent = "Confira a data de início em script.js.";
    return;
  }
  const now = new Date();
  let years = now.getFullYear() - start.getFullYear();
  let months = now.getMonth() - start.getMonth();
  let days = now.getDate() - start.getDate();
  if (days < 0) {
    months--;
    days += new Date(now.getFullYear(), now.getMonth(), 0).getDate();
  }
  if (months < 0) { years--; months += 12; }
  const totalDays = Math.floor((new Date(now.getFullYear(), now.getMonth(), now.getDate()) - start) / 86400000);
  const parts = [];
  if (years) parts.push(`${years} ${years === 1 ? "ano" : "anos"}`);
  if (months) parts.push(`${months} ${months === 1 ? "mês" : "meses"}`);
  if (days || parts.length === 0) parts.push(`${days} ${days === 1 ? "dia" : "dias"}`);
  counter.textContent = `${parts.join(", ")} juntos · ${totalDays} dias de história ♡`;
}
updateCounter();

const musicToggle = document.getElementById("musicToggle");
const ourSong = document.getElementById("ourSong");
if (songFile) ourSong.src = songFile;
musicToggle.addEventListener("click", async () => {
  if (!songFile) {
    alert('A música de vocês é “Until I Found You” ♡ Para adicioná-la, incorpore o player oficial do YouTube: abra o vídeo oficial, toque em Compartilhar → Incorporar e cole o iframe no index.html. Assim vocês ouvem a música sem hospedar uma cópia não autorizada.');
    return;
  }
  try {
    if (ourSong.paused) {
      await ourSong.play();
      musicToggle.setAttribute("aria-pressed", "true");
      musicToggle.innerHTML = "♫ <span>Pausar música</span>";
    } else {
      ourSong.pause();
      musicToggle.setAttribute("aria-pressed", "false");
      musicToggle.innerHTML = "♫ <span>Nossa música</span>";
    }
  } catch {
    alert("Não consegui tocar o áudio. Confira se o arquivo está em assets/nossa-musica.mp3.");
  }
});

document.getElementById("surpriseButton").addEventListener("click", () => {
  const message = document.getElementById("surpriseMessage");
  message.hidden = !message.hidden;
  document.getElementById("surpriseButton").textContent = message.hidden ? "Desbloquear surpresa ♡" : "Surpresa desbloqueada ♥";
  if (!message.hidden) message.scrollIntoView({ behavior: "smooth", block: "nearest" });
});

const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightboxImage");
const lightboxCaption = document.getElementById("lightboxCaption");
document.querySelectorAll(".photo-card[data-full]").forEach(card => {
  card.addEventListener("click", () => {
    const img = card.querySelector("img");
    lightboxImage.src = img.currentSrc || img.src;
    lightboxImage.alt = img.alt;
    lightboxCaption.textContent = card.dataset.caption || card.querySelector(".photo-caption")?.textContent || "";
    lightbox.showModal();
  });
});
document.getElementById("lightboxClose").addEventListener("click", () => lightbox.close());
lightbox.addEventListener("click", event => {
  if (event.target === lightbox) lightbox.close();
});
document.getElementById("addPhotoCard").addEventListener("click", () => {
  alert("Adicione suas fotos à pasta assets/fotos e atualize os caminhos no index.html. O arquivo LEIA-ME.md explica o passo a passo.");
});
