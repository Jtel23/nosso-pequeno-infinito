# Nosso Pequeno Infinito ♡

Um site romântico responsivo para guardar memórias de Julio e Duda. Feito com HTML, CSS e JavaScript puro — sem instalação de dependências.

## Pré-visualizar no computador
1. Extraia a pasta `nosso-pequeno-infinito`.
2. Abra `index.html` no navegador.
3. Para testar como celular, use as ferramentas de desenvolvedor do navegador ou abra o site no seu telefone depois de publicar.

## Personalização essencial
### 1. Trocar as fotos
As oito fotos que você enviou já foram incluídas em `assets/fotos/` como `foto-01.jpg` até `foto-08.jpg`. Para trocar ou adicionar fotos, use estes nomes e atualize os blocos da galeria.
- `foto-01.jpg`
- `foto-02.jpg`
- `foto-03.jpg`
- `foto-04.jpg`
- `foto-05.jpg`

As imagens atuais de exemplo são apenas ilustrativas e carregam imagens de demonstração enquanto os arquivos pessoais não existem. Para um site mais rápido, redimensione as fotos para cerca de 1200 px no lado maior e comprima-as em JPG/WebP. Não coloque fotos privadas que vocês não queiram tornar públicas.

Para adicionar mais fotos, copie um bloco `<button class="photo-card ...">` na seção `#photoGrid` do `index.html`, atualize o caminho de `data-full`, o `src`, o texto alternativo e a legenda.

### 2. Ajustar a data do relacionamento
Abra `script.js` e edite:
```js
const relationshipStart = "2026-08-04";
```
A data está configurada como `"2026-08-04"`, o dia em que vocês se conheceram. Se quiser contar a partir do início oficial do namoro, troque pela data correspondente.

### 3. Adicionar música ou vídeo
**Opção A — áudio próprio/licenciado:** coloque o arquivo em `assets/nossa-musica.mp3` e altere em `script.js`:
```js
const songFile = "assets/nossa-musica.mp3";
```
Use apenas áudio que você tenha direito de publicar. O navegador só inicia a música depois do toque no botão.

**Opção B — vídeo do YouTube:** no YouTube, selecione **Compartilhar → Incorporar** e copie o iframe. Cole-o no `index.html` na área desejada. Use uma URL de incorporação `https://www.youtube.com/embed/ID_DO_VIDEO`. Confira as permissões do vídeo e evite conteúdo privado.

### 4. Editar textos e bilhetes
Abra `index.html` em um editor de texto (por exemplo, VS Code) e procure por:
- `Quando nossos caminhos se cruzaram`
- `O dia em que virou “nós”`
- `Minha Estrelinha`
- `Dona da razão™`
- `Pra você, minha Duda`
- `Se eu pudesse escolher de novo`

Substitua os textos de exemplo por detalhes verdadeiros de vocês. Lembre-se de mudar também as datas da linha do tempo.

## Publicar gratuitamente com GitHub Pages
1. Crie ou entre na sua conta do GitHub.
2. Crie um repositório novo, por exemplo `nosso-pequeno-infinito`.
3. Envie os arquivos e pastas desta pasta para o repositório, mantendo `index.html` na raiz.
4. No repositório, vá a **Settings → Pages**.
5. Em **Build and deployment**, escolha **Deploy from a branch**, selecione `main` e a pasta `/ (root)`, e salve.
6. Aguarde a publicação e abra o endereço que o GitHub Pages mostrar em Settings → Pages.

Outra opção simples é Netlify: faça login, escolha a opção de adicionar um site e arraste a pasta do site para o fluxo de deploy manual, se disponível na sua conta.

## Privacidade — leia antes de publicar
Este site é estático e público. Qualquer pessoa com o endereço pode ver as fotos e os textos; o link não é uma senha. Para fotos pessoais, compartilhe somente imagens com as quais ambos estejam confortáveis. GitHub Pages não fornece senha para proteger um site estático. Se precisar de acesso privado, use uma plataforma com controle de acesso real.

## Arquivos
- `index.html` — conteúdo, seções e textos.
- `style.css` — aparência, cores e layout responsivo.
- `script.js` — contador, botão de música, galeria ampliável e surpresa.
- `assets/fotos/` — pasta para as fotos pessoais.
